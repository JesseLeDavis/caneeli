    </main>
    <footer>
        <div class="container">
            <div class="socials-container">
                <a href="https://www.tiktok.com/@caneeli.designs" target="_blank"><img class="hover-grow" src="/assets/images/tiktok.svg"></a>
                <img class="hover-grow" src="/assets/images/instagram.svg">
                <img class="hover-grow" src="/assets/images/facebook.svg">
            </div>
            <div class="bottom-nav">
                <a class="hover-grow" href="/">Home</a>
                <a class="hover-grow" href="/pages/shop/index.php">Shop</a>
                <a class="hover-grow" href="/pages/about.php">About Me</a>
                <a class="hover-grow" href="/pages/contact.php">Contact Me</a>
            </div>
            <div class="info-container">
                <div class="tos-container">
                    <a href="/pages/privacy.php">Privacy Policy</a>
                    <a href="/pages/terms.php">Terms of Service</a>
                </div>
                <p>© 2026 Caneeli Designs</p>
            </div>
            <div class="">

            </div>
        </div>
    </footer>
    <script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>
</body>
</html>
